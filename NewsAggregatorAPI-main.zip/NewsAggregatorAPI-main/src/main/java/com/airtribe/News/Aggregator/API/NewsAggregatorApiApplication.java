package com.airtribe.News.Aggregator.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsAggregatorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsAggregatorApiApplication.class, args);
	}

}
