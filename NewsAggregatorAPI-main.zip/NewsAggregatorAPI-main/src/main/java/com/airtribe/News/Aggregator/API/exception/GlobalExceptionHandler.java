package com.airtribe.News.Aggregator.API.exception;

public class GlobalExceptionHandler {
}
