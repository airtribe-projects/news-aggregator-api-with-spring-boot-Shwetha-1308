package com.airtribe.News.Aggregator.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsAggregatorApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
